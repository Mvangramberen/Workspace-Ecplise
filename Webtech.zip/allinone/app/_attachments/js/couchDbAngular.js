 var allinone = angular.module('allinone',[$http]);

allinone.controller('allinoneCtrl',['serverSrv', function($scope, $http, $resource){

    
console.log("scope personen" + serverSrv.getAllItems);
}]);

